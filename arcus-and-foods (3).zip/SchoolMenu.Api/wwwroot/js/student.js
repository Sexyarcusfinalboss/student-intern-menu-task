// student.js

const IMAGES = {
  soup:    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTClRFKtJugWZl3Pfl-sbrLfWwe1KjLCWobRG1tXeHQaA&s=10",
  main:    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQHWohTafVqd8fp9Q9sqKKj7z5TTwnPOmrNpGrS49qrFg&s=10",
  dessert: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS019UK_moNIawJHkZOumrJfptVvCDZPXNvrJjRGYGzbQ&s=10",
};

function dateToStr(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

let currentDate = new Date();

async function loadMenu(date) {
  const container = document.getElementById("menu-container");

  document.getElementById("menu-date").textContent =
    date.toLocaleDateString("bg-BG", { weekday: "long", day: "numeric", month: "long" });

  const menu = await getMenuForDate(dateToStr(date));

  if (!menu) {
    container.innerHTML =
      `<div class="alert">Менюто за този ден все още не е публикувано. Провери по-късно!</div>`;
    return;
  }

  const card = (img, label, name, allergens) => `
    <div class="food-card">
      <img class="food-img" src="${img}" alt="${label}">
      <div class="food-info">
        <small>${label}</small>
        <strong>${name ?? "Няма"}</strong>
        <div class="food-meta">
          <div class="food-field">
            <span class="field-label">Алергени</span>
            <span class="field-value">${allergens ?? ""}</span>
          </div>
          <div class="food-field">
            <span class="field-label">Съставки</span>
            <span class="field-value"></span>
          </div>
        </div>
      </div>
    </div>`;

  container.innerHTML = `
    <div class="food-grid">
      ${card(IMAGES.soup,    "Супа",    menu.soup?.name,       menu.soup?.allergens)}
      ${card(IMAGES.main,    "Основно", menu.mainCourse?.name, menu.mainCourse?.allergens)}
      ${card(IMAGES.dessert, "Десерт",  menu.dessert?.name,    menu.dessert?.allergens)}
    </div>
    ${menu.notes ? `<p class="notes">${menu.notes}</p>` : ""}`;
}

loadMenu(currentDate);

function changeDay(days) {
  currentDate.setDate(currentDate.getDate() + days);
  loadMenu(currentDate);
}

document.getElementById("btn-prev").onclick  = () => changeDay(-1);
document.getElementById("btn-next").onclick  = () => changeDay(+1);
document.getElementById("btn-today").onclick = () => {
  currentDate = new Date();
  loadMenu(currentDate);
};
